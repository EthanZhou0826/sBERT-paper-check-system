import os

from PIL import Image

path = r'D:\mycode\202303\horse\cnn_classify\newdata\train'
count = 1
for root,dirs,files in os.walk(path):
    for filename in files:
        filepath = os.path.join(root, filename)
        os.rename(filepath,os.path.join(root, str(count)+'.jpg'))
        count+=1

