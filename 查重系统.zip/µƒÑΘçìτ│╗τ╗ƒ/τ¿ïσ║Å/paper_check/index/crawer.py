import csv
import datetime
import os
import requests
from lxml import etree
from tqdm import tqdm

workdir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

headers = {
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36'
}


def main():
    date = datetime.datetime.today()
    month = date.month
    year = date.year
    day = date.day
    results = []
    for count in range(14, int(day)):
        if count < 10:
            url = 'https://www.chinanews.com.cn/scroll-news/'+str(year) +'/0'+str(month) +'0' + str(count) + '/news.shtml'
        else:
            url = 'https://www.chinanews.com.cn/scroll-news/'+str(year) +'/0'+str(month) + str(count) + '/news.shtml'
        lj1 = []
        # 发起请求,获取页面里面的新闻链接
        req = requests.get(url.replace('\n', ''), headers=headers)
        # 设置网页编码，不设置会乱码
        req.encoding = 'utf8'
        ht = etree.HTML(req.text)
        # 获取分类的数据还有正文链接
        fl = ht.xpath("//div[@class='dd_lm']/a/text()")
        lj = ht.xpath("//div[@class='dd_bt']/a/@href")
        # 链接有两种格式，分别组合成可以用的
        for j in lj:
            if j[:5] == '//www':
                lj1.append('https:' + j)
            else:
                lj1.append('https://www.chinanews.com.cn/' + j)
        lj1 = lj1[0:10]
        for k in tqdm(lj1):
            try:
                reqs = requests.get(k, headers=headers, timeout=10)
                reqs.encoding = 'utf8'
                ht1 = etree.HTML(reqs.text)
                bt = ht1.xpath("//h1[@class='content_left_title']/text()")  # 标题
                if bt:
                    title = ht1.xpath("//h1[@class='content_left_title']/text()")[0]  # 标题
                    comment = ht1.xpath("//div[@class='left_zw']/p/text()")[1]  # 简介
                else:
                    title = ht1.xpath("//div[@class='content_title']/div[@class='title']/text()")[0]
                    comment = ht1.xpath("//div[@class='content_desc']/p/text()")[1]  # 简介
                results.append(title)
                print([comment])
            except Exception as arr:
                print(arr)
                continue
    return results

if __name__ == '__main__':
    main()
