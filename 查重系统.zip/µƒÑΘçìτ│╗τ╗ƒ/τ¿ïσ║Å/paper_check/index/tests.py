from django.test import TestCase

# Create your tests here.
import difflib

def similar(text1,text2):

   # 创建SequenceMatcher对象

   s = difflib.SequenceMatcher(None,text1,text2)

   # 计算两个序列的相似程度

   return s.ratio()

if __name__ == '__main__':

    text1 = '你好啊'

    text2 = '这也是一段文本'

    print('两段文本相似度为：',similar(text1,text2))
