from django.db import models


class Info(models.Model):
    id = models.AutoField(primary_key=True)
    number = models.CharField(verbose_name="检测编号", default='', max_length=100)
    name = models.CharField(verbose_name="论文名称", default='', max_length=100)
    result = models.CharField(verbose_name="相似度", default='', max_length=100)
    status = models.CharField(verbose_name="状态", default='', max_length=100)
    create_time = models.DateTimeField('创建时间', auto_now_add=True)
    content = models.TextField(verbose_name="内容", default='', null=True)
    author = models.CharField(verbose_name="论文作者", default='', max_length=100, null=True)
    total_zs = models.IntegerField(verbose_name="总字数")
    note= models.CharField(verbose_name="论文作者", default='', max_length=255, null=True)
    def __str__(self):
        return self.name

    class Meta:
        db_table = 'info'

class Paper(models.Model):
    id = models.AutoField(primary_key=True)
    info = models.ForeignKey(Info,on_delete=models.CASCADE)
    path = models.CharField(verbose_name="报告路径", default='', max_length=255)
    owner = models.CharField(verbose_name="操作人", default='', max_length=100)
    create_time = models.DateTimeField('创建时间', auto_now_add=True)
    def __str__(self):
        return self.path

    class Meta:
        db_table = 'paper'

class Crawer(models.Model):
    id = models.AutoField(primary_key=True)
    number = models.CharField(verbose_name="检测编号", default='', max_length=100)
    content = models.TextField(verbose_name="我的文本",default='')
    score = models.CharField(verbose_name="文本相似度", default='', max_length=255)
    result = models.CharField(verbose_name="相似文本", default='', max_length=100)
    owner = models.CharField(verbose_name="操作人", default='', max_length=100)
    total_zs = models.IntegerField(verbose_name="总字数")
    create_time = models.DateTimeField('创建时间', auto_now_add=True)

    def __str__(self):
        return self.score

    class Meta:
        db_table = 'crawer'
class FileTable(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(verbose_name="文件名称", default='', max_length=100)
    size = models.CharField(verbose_name="文件大小", default='', max_length=100)
    file_type = models.CharField(verbose_name="文件类型", default='', max_length=100)
    lw_name = models.CharField(verbose_name="论文题目", default='', max_length=100,null=True)
    author =models.CharField(verbose_name="论文作者", default='', max_length=100,null=True)
    owner = models.CharField(verbose_name="操作人", default='', max_length=100)
    pid = models.IntegerField(verbose_name="父目录",default=0)
    create_time = models.DateTimeField('创建时间', auto_now_add=True)
    content = models.TextField(verbose_name="内容",default='',null=True)

    def __str__(self):
        return self.name

    class Meta:
        db_table = 'file_table'


class ShouCang(models.Model):
    id = models.AutoField(primary_key=True)
    user = models.CharField(default='',max_length=100)
    file_data = models.ForeignKey(FileTable,on_delete=models.CASCADE)
    def __str__(self):
        return self.id

    class Meta:
        db_table = 'shoucang'