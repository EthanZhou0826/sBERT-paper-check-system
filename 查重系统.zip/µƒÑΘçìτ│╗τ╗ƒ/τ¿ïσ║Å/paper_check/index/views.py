import datetime
import os

from django.conf import settings
from django.core.paginator import Paginator
from django.db.models import Count
from django.http import HttpResponseRedirect, HttpResponse, HttpResponseForbidden, JsonResponse, StreamingHttpResponse
from django.shortcuts import render
from django.utils.encoding import escape_uri_path
from docxtpl import DocxTemplate
from user.models import User
from utils import common
from .predict_text import main
from win32com import client
from .models import *
from .crawer import main as craw_main

workdir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def file_iterator(file_path, chunk_size=512):
    """
    文件生成器,防止文件过大，导致内存溢出
    :param file_path: 文件绝对路径
    :param chunk_size: 块大小
    :return: 生成器
    """
    with open(file_path, mode='rb') as f:
        while True:
            c = f.read(chunk_size)
            if c:
                yield c
            else:
                break


def login(request):
    """
    跳转登录
    :param request:
    :return:
    """
    return render(request, 'login.html')


def forget_password(request):
    return render(request, 'forget_password.html')


def reset_pwd(request, phone):
    return render(request, 'reset_pwd.html', locals())


def to_modify_pwd(request):
    phone = request.GET.get('phone')
    user = User.objects.filter(phone=phone).first()
    if user:
        return JsonResponse({'phone': phone})


def register(request):
    """
    跳转注册
    :param request:
    :return:
    """
    return render(request, 'register.html')


def index(request):
    """
    跳转首页
    :param request:
    :return:
    """
    username = request.session.get('username', '')
    role = int(request.session.get('role', 3))
    user_id = request.session.get('user_id', 1)
    total_user = len(User.objects.all())
    total_folder = FileTable.objects.filter(file_type='文件夹').count()
    total_info = Info.objects.count()
    total_paper = Paper.objects.count()
    date = datetime.datetime.today()
    month = date.month
    year = date.year
    day = date.day
    current_day = "{}-{}-{}".format(year, month, day)
    # 获取近七天的操作
    seven_days = common.get_recent_seven_day()
    seven_data_dict = dict.fromkeys(seven_days, 0)
    for i in seven_days:
        d = datetime.timedelta
        r = Info.objects.filter(create_time__year=i.split('-')[0], create_time__month=i.split('-')[1],
                                create_time__day=i.split('-')[2]).all()
        if r:
            seven_data_dict[i] = r.count()
    seven_count_list = [seven_data_dict[x] for x in seven_days]
    return render(request, 'index.html', locals())


def login_out(request):
    """
    注销登录
    :param request:
    :return:
    """
    del request.session['username']
    return HttpResponseRedirect('/')


def personal(request):
    username = request.session.get('username')
    role_id = request.session.get('role')
    user = User.objects.filter(name=username).first()
    return render(request, 'personal.html', locals())


def to_file(request, folder_id):
    username = request.session.get('username')
    role = request.session.get('role')
    user = User.objects.filter(name=username).first()
    return render(request, 'file_data.html', locals())


def to_folder(request):
    username = request.session.get('username')
    role = request.session.get('role')
    user = User.objects.filter(name=username).first()
    file_table = FileTable.objects.filter(file_type='文件夹').all()
    folder_names = []
    for i in file_table:
        folder_names.append(i.name)
    return render(request, 'folder_data.html', locals())


def to_paper(request):
    username = request.session.get('username')
    role = request.session.get('role')
    user_id = request.session.get('user_id')
    return render(request, 'paper.html', locals())


def get_size(start_path):
    total_size = 0
    for dirpath, dirnames, filenames in os.walk(start_path):
        for f in filenames:
            fp = os.path.join(dirpath, f)
            # skip if it is symbolic link
            if not os.path.islink(fp):
                total_size += os.path.getsize(fp)
    return '%.3f' % (total_size / 1024 / 1024)


def get_file(request):
    """
    获取列表信息 | 模糊查询
    :param request:
    :return:
    """
    keyword = request.GET.get('name')
    page = request.GET.get("page", '')
    limit = request.GET.get("limit", '')
    folder_id = request.GET.get("folder_id", '')
    response_data = {}
    response_data['code'] = 0
    response_data['msg'] = ''
    data = []
    if keyword is None:
        results_obj = FileTable.objects.exclude(file_type='文件夹').filter(pid=folder_id).all()
    else:
        results_obj = FileTable.objects.exclude(file_type='文件夹').filter(name__contains=keyword).filter(
            pid=folder_id).all()
    paginator = Paginator(results_obj, limit)
    results = paginator.page(page)
    if results:
        for user in results:
            record = {
                "id": user.id,
                "name": user.name,
                "size": user.size,
                "file_type": user.file_type,
                "author": user.author,
                'lw_name': user.lw_name,
                'create_time': user.create_time.strftime('%Y-%m-%d %H:%m:%S'),
            }
            data.append(record)
        response_data['count'] = len(results_obj)
        response_data['data'] = data

    return JsonResponse(response_data)


def getFileFolderSize(fileOrFolderPath):
    """get size for file or folder"""
    totalSize = 0

    if not os.path.exists(fileOrFolderPath):
        return totalSize

    if os.path.isfile(fileOrFolderPath):
        totalSize = os.path.getsize(fileOrFolderPath)  # 5041481
        return totalSize

    if os.path.isdir(fileOrFolderPath):
        with os.scandir(fileOrFolderPath) as dirEntryList:
            for curSubEntry in dirEntryList:
                curSubEntryFullPath = os.path.join(fileOrFolderPath, curSubEntry.name)
                if curSubEntry.is_dir():
                    curSubFolderSize = getFileFolderSize(curSubEntryFullPath)  # 5800007
                    totalSize += curSubFolderSize
                elif curSubEntry.is_file():
                    curSubFileSize = os.path.getsize(curSubEntryFullPath)  # 1891
                    totalSize += curSubFileSize

            return totalSize


def get_folder(request):
    """
    获取列表信息 | 模糊查询
    :param request:
    :return:
    """
    keyword = request.GET.get('name')
    page = request.GET.get("page", '')
    limit = request.GET.get("limit", '')
    response_data = {}
    response_data['code'] = 0
    response_data['msg'] = ''
    data = []
    if keyword is None:
        results_obj = FileTable.objects.filter(file_type='文件夹').all()
    else:
        results_obj = FileTable.objects.filter(name__contains=keyword, file_type='文件夹').all()
    paginator = Paginator(results_obj, limit)
    results = paginator.page(page)
    if results:
        for result in results:
            if result.file_type == '文件夹':
                count = len(os.listdir(os.path.join(workdir, 'static/file_data', result.name)))
            else:
                count = 1
            record = {
                "id": result.id,
                "name": result.name,
                "size": str(getFileFolderSize(os.path.join(workdir, 'static/file_data', result.name)))+"字节",
                "file_type": result.file_type,
                "file_count": count,
                'create_time': result.create_time.strftime('%Y-%m-%d %H:%m:%S'),
            }
            data.append(record)
        response_data['count'] = len(results_obj)
        response_data['data'] = data

    return JsonResponse(response_data)


def get_data(request):
    """
    获取列表信息 | 模糊查询
    :param request:
    :return:
    """
    keyword = request.GET.get('name')
    page = request.GET.get("page", '')
    limit = request.GET.get("limit", '')
    response_data = {}
    response_data['code'] = 0
    response_data['msg'] = ''
    data = []
    files = ShouCang.objects.filter(user=request.session.get('username')).all()
    if keyword is None:
        files = ShouCang.objects.filter(user=request.session.get('username')).all()

    paginator = Paginator(files, limit)
    results = paginator.page(page)
    if results:
        for result in results:
            result = result.file_data
            if result.file_type == '文件夹':
                count = len(os.listdir(os.path.join(workdir, 'static/file_data', result.name)))
            else:
                count = 1
            record = {
                "id": result.id,
                "name": result.name,
                "size": result.size,
                "file_type": result.file_type,
                "file_count": count,
                'create_time': result.create_time.strftime('%Y-%m-%d %H:%m:%S'),
            }
            data.append(record)
        response_data['count'] = len(files)
        response_data['data'] = data

    return JsonResponse(response_data)


def get_info(request):
    """
    获取列表信息 | 模糊查询
    :param request:
    :return:
    """
    keyword = request.GET.get('name')
    page = request.GET.get("page", '')
    limit = request.GET.get("limit", '')
    response_data = {}
    response_data['code'] = 0
    response_data['msg'] = ''
    data = []
    if keyword is None:
        results_obj = Info.objects.all()
    else:
        results_obj = Info.objects.filter(name__contains=keyword).all()
    paginator = Paginator(results_obj, limit)
    results = paginator.page(page)
    if results:
        for result in results:
            record = {
                "id": result.id,
                "name": result.name,
                "total_zs": result.total_zs,
                "number": result.number,
                "author": result.author,
                "status": result.status,
                'result': result.result,
                'create_time': result.create_time.strftime('%Y-%m-%d %H:%m:%S'),
            }
            data.append(record)
        response_data['count'] = len(results_obj)
        response_data['data'] = data

    return JsonResponse(response_data)


def text_cc(request):
    """
    跳转页面
    """
    username = request.session.get('username', '')
    role = int(request.session.get('role', 3))
    user_id = request.session.get('user_id', 1)
    files = FileTable.objects.exclude(file_type='文件夹').all()
    return render(request, 'text_cc.html', locals())


def sc_list(request):
    """
    跳转页面
    """
    username = request.session.get('username', '')
    role = int(request.session.get('role', 3))
    user_id = request.session.get('user_id', 1)
    return render(request, 'sc.html', locals())


def get_wlcc(request):
    keyword = request.GET.get('name')
    page = request.GET.get("page", '')
    limit = request.GET.get("limit", '')
    response_data = {}
    response_data['code'] = 0
    response_data['msg'] = ''
    data = []
    if keyword is None:
        results_obj = Crawer.objects.all()
    else:
        results_obj = Crawer.objects.filter(content__contains=keyword).all()
    paginator = Paginator(results_obj, limit)
    results = paginator.page(page)
    if results:
        for result in results:
            record = {
                "id": result.id,
                "content": result.content,
                "score": result.score,
                "number": result.number,
                'result': result.result,
                "total_zs":result.total_zs,
                'create_time': result.create_time.strftime('%Y-%m-%d %H:%m:%S'),
            }
            data.append(record)
        response_data['count'] = len(results_obj)
        response_data['data'] = data

    return JsonResponse(response_data)


def wlpc(request):
    """
    跳转页面
    """
    username = request.session.get('username', '')
    role = int(request.session.get('role', 3))
    user_id = request.session.get('user_id', 1)
    return render(request, 'wlpc.html', locals())


def get_uuid():
    import random
    import string

    n = "0123456789"
    s = string.ascii_letters
    i = 0
    psd = ""

    ku = n + s

    while True:
        while i < 6:
            temp = random.choice(ku)
            psd += temp
            i += 1
        for o in n:
            if o not in psd:
                a = True
            else:
                a = False
                print(psd)
                break
        if psd.isdigit() or a:
            i = 0
            psd = ""
            continue
        else:
            break
    return psd


def edit_data(request):
    """
    修改信息
    """
    response_data = {}
    user_id = request.POST.get('id')
    username = request.POST.get('username')
    phone = request.POST.get('phone')
    User.objects.filter(id=user_id).update(
        name=username,
        phone=phone)
    response_data['msg'] = 'success'
    return JsonResponse(response_data, status=201)


def add_file(request):
    lw_name = request.POST.get('lw_name')
    author = request.POST.get('author')
    content = request.POST.get('content')
    if not content:
        file_name = request.POST.get('file_name')
        folder_name = request.POST.get('folder_name')
        file_folder = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'static', 'file_data',
                                   folder_name)
        file_path = os.path.join(file_folder, file_name)
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.readlines()
        content = "".join(content)
        size = str(os.path.getsize(file_path)) + '字节'
        file_type = file_path.split('.')[1]
        pid = FileTable.objects.filter(name=folder_name).first().id
    else:
        file_name = lw_name
        size = 0
        file_type = '文本'
        pid = 0
    FileTable.objects.create(
        name=file_name,
        author=author,
        content=content,
        lw_name=lw_name,
        size=size,
        file_type=file_type,
        owner='admin',
        pid=pid
    )
    response_data = {}
    response_data['msg'] = 'success'
    return JsonResponse(response_data, status=201)


def rename(request):
    file_id = request.POST.get('id')
    new_folder = request.POST.get("name")
    file_obj = FileTable.objects.filter(id=file_id).first()
    path = os.path.join(workdir, 'static', 'file_data', file_obj.name)
    new_path = os.path.join(workdir, 'static', 'file_data', new_folder)
    FileTable.objects.filter(id=file_id).update(
        name=new_folder
    )
    os.rename(path, new_path)
    return JsonResponse({'msg': 'ok'}, status=201)


def del_sc(request):
    """
    删除信息
    """
    user_id = request.POST.get('id')
    result = ShouCang.objects.filter(file_data=user_id, user=request.session.get('username')).first()
    try:
        if not result:
            response_data = {'error': '删除失败！', 'message': '找不到id为%s' % user_id}
            return JsonResponse(response_data, status=403)
        result.delete()
        response_data = {'message': '删除成功！'}
        return JsonResponse(response_data, status=201)
    except Exception as e:
        response_data = {'message': '删除失败！'}
        return JsonResponse(response_data, status=403)


def del_data(request):
    """
    删除信息
    """
    user_id = request.POST.get('id')
    result = FileTable.objects.filter(id=user_id).first()
    try:
        if not result:
            response_data = {'error': '删除失败！', 'message': '找不到id为%s' % user_id}
            return JsonResponse(response_data, status=403)
        result.delete()
        response_data = {'message': '删除成功！'}
        return JsonResponse(response_data, status=201)
    except Exception as e:
        response_data = {'message': '删除失败！'}
        return JsonResponse(response_data, status=403)

def del_wlpc(request):
    """
    删除信息
    """
    user_id = request.POST.get('id')
    result = Crawer.objects.filter(id=user_id).first()
    try:
        if not result:
            response_data = {'error': '删除失败！', 'message': '找不到id为%s' % user_id}
            return JsonResponse(response_data, status=403)
        result.delete()
        response_data = {'message': '删除成功！'}
        return JsonResponse(response_data, status=201)
    except Exception as e:
        response_data = {'message': '删除失败！'}
        return JsonResponse(response_data, status=403)
def del_info(request):
    """
    删除信息
    """
    user_id = request.POST.get('id')
    result = Info.objects.filter(id=user_id).first()
    try:
        if not result:
            response_data = {'error': '删除失败！', 'message': '找不到id为%s' % user_id}
            return JsonResponse(response_data, status=403)
        result.delete()
        response_data = {'message': '删除成功！'}
        return JsonResponse(response_data, status=201)
    except Exception as e:
        response_data = {'message': '删除失败！'}
        return JsonResponse(response_data, status=403)


def del_paper(request):
    """
    删除信息
    """
    user_id = request.POST.get('id')
    result = Paper.objects.filter(id=user_id).first()
    try:
        if not result:
            response_data = {'error': '删除失败！', 'message': '找不到id为%s' % user_id}
            return JsonResponse(response_data, status=403)
        path = os.path.join(workdir, 'static/file_data', result.path)
        if os.path.exists(path):
            os.rmdir(path)
        result.delete()
        response_data = {'message': '删除成功！'}
        return JsonResponse(response_data, status=201)
    except Exception as e:
        response_data = {'message': '删除失败！'}
        return JsonResponse(response_data, status=403)


def get_paper(request):
    keyword = request.GET.get('name')
    page = request.GET.get("page", '')
    limit = request.GET.get("limit", '')
    response_data = {}
    response_data['code'] = 0
    response_data['msg'] = ''
    data = []
    if keyword is None:
        results_obj = Paper.objects.all()
    else:
        results_obj = Paper.objects.filter(owner__contains=keyword).all()
    paginator = Paginator(results_obj, limit)
    results = paginator.page(page)
    if results:
        for result in results:
            record = {
                "id": result.id,
                "name": result.info.name,
                "author": result.info.author,
                "owner": result.owner,
                "path": result.path,
                'create_time': result.create_time.strftime('%Y-%m-%d %H:%m:%S'),
            }
            data.append(record)
        response_data['count'] = len(results_obj)
        response_data['data'] = data

    return JsonResponse(response_data)


def add_folder(request):
    name = request.POST.get('name')
    is_exists = FileTable.objects.filter(name=name, file_type='文件夹').first()
    if not is_exists:
        FileTable.objects.create(
            name=name,
            author='',
            content='',
            lw_name='',
            size=0,
            file_type='文件夹',
            owner='admin',
            pid=0
        )
        path = os.path.join(workdir, 'static/file_data', name)
        if not os.path.exists(path):
            os.mkdir(path)
        response_data = {}
        response_data['msg'] = 'success'
        return JsonResponse(response_data, status=201)
    else:
        return JsonResponse({'msg': '文件夹已存在！'}, status=401)


def save_file(file):
    """
    保存文件
    """
    if file is not None:
        file_dir = os.path.join(workdir, 'static', 'uploadImg')
        if not os.path.exists(file_dir):
            os.mkdir(file_dir)
        file_name = os.path.join(file_dir, file.name)
        with open(file_name, 'wb')as f:
            # chunks()每次读取数据默认 我64k
            for chunk in file.chunks():
                f.write(chunk)
            f.close()
        return file_name
    else:
        return None


def file(request):
    myFile = request.FILES.get("file", None)
    folder_name = request.POST.get('folder')
    if myFile:
        if folder_name:
            save_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'static', 'file_data',
                                     folder_name)
        else:
            save_path = os.path.join(workdir, 'static/lw')
        destination = open(os.path.join(save_path, myFile.name),
                           'wb+')
        for chunk in myFile.chunks():
            destination.write(chunk)
        destination.close()
    return JsonResponse({'msg': 'ok', 'file_name': myFile.name})


def switch_pdf(docx_file):
    """
    将word文档转化为pdf文档
    :param path: 文件夹路径
    :param name: 文件名
    :return:
    """
    import pythoncom
    pythoncom.CoInitialize()
    (file_path, tempfilename) = os.path.split(docx_file)
    pdfPath = os.path.join(file_path, tempfilename.split('.')[0] + '.pdf')  # pdf路径

    word = client.Dispatch("Word.Application")  # 打开word应用程序
    # for file in files:
    doc = word.Documents.Open(docx_file)  # 打开word文件
    doc.SaveAs(pdfPath, FileFormat=17)  # 另存为后缀为".pdf"的文件，其中参数17表示为pdf
    doc.Close()  # 关闭原来word文件
    word.Quit()
    return


def write_doc(name, author, create_time, result, all_results, number, files, total_zs):
    """
    基于变化检测图斑生成word报告
    :param start_time: 检测时间
    :param outputPath: 报告的路径
    :return:
    """
    try:
        tpl_file = os.path.join(settings.BASE_DIR, 'static', 'template.docx')  # 模板文件路径
        tpl = DocxTemplate(tpl_file)
        outputPath = os.path.join(settings.BASE_DIR, 'static', 'docx')
        # 判断路径是否存在
        if not os.path.exists(outputPath):
            os.makedirs(outputPath)
        context = {
            "create_time": create_time,
            "number": number,
            "name": name,
            "author": author,
            "result": result,
            "total_zs": total_zs,
            "all_results": all_results,
            "files": files,
        }
        report_file = os.path.join(outputPath, name + '.docx')
        tpl.render(context)
        tpl.save(report_file)
        # 调用word转pdf方法
        switch_pdf(report_file)
        # return JsonResponse({'msg': '报告生成成功！', 'filename': name + '.pdf', 'status': True}, status=200)
    except Exception as e:
        pass
        # return JsonResponse('报告生成失败！请查看后端日志')


def add_wlpc(request):
    content = request.POST.get('content')
    results = craw_main()
    all_values = []
    for i in results:
        result = main(content, i)
        all_values.append(result)
    number = get_uuid()
    max_value = max(all_values)
    index1 = all_values.index(max_value)
    result = results[index1]
    Crawer.objects.create(
        number=number,
        content=content,
        score='{:.2%}'.format(max_value),
        result=result,
        total_zs=len(content),
    )
    return JsonResponse({"score": '{:.2%}'.format(max_value), 'result': result,'content':content})

def predict(request):
    author = request.POST.get('author')
    name = request.POST.get('lw_name')
    content = request.POST.get('content')
    file_name = request.POST.get('file_name')
    file_id = request.POST.get('file_id')
    all_content = FileTable.objects.exclude(file_type='文件夹').all()
    if not content:
        if file_name:
            file_path = os.path.join(workdir, 'static/lw', file_name)
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.readlines()
        else:
            content = FileTable.objects.filter(id=file_id).first().content
            all_content = FileTable.objects.exclude(id=file_id).exclude(file_type='文件夹').all()
    try:

        all_results = []
        all_values = []
        files = []
        for i in all_content:
            files.append(i.name)
            try:
                from .sentence_similarity_Bert.examples import shibie
                result = shibie.main(i.content, content)
            except Exception as e:
                result = main(content, i.content)
            all_results.append({'name': i.name, 'result': '{:.2%}'.format(result)})
            all_values.append(result)
        number = get_uuid()
        create_time = datetime.datetime.now()
        content = ''.join(content)
        info = Info.objects.create(name=name,
                                   number=number,
                                   author=author,
                                   status="成功",
                                   content=content,
                                   result='{:.2%}'.format(max(all_values)),
                                   total_zs=len(content),
                                   note=str(all_results),
                                   )
        Paper.objects.create(
            info=info,
            owner=request.session.get('username', 'admin'),
            path=name + '.pdf',
        )
        write_doc(name, author, create_time, '{:.2%}'.format(max(all_values)), all_results, number, files, len(content))
        return JsonResponse({"result": '{:.2%}'.format(max(all_values)), 'file_name': name + '.pdf'})
    except Exception as e:
        print(e)
        return JsonResponse({"error": 403})


def analysis(request):
    results = Pic.objects.values('result').annotate(myCount=Count('result'))  # 返回查询集合
    country = []
    count = []
    for i in results:
        country.append(i['result'])
        count.append(i['myCount'])
    result1 = Pic.objects.values('owner').annotate(myCount=Count('owner'))  # 返回查询集合
    values = []
    for i in result1:
        values.append({'name': i['owner'], 'value': i['myCount']})

    username = request.session.get('username', 'admin')
    role = int(request.session.get('role', 3))
    user_id = request.session.get('user_id', 1)
    return render(request, 'analysis.html', locals())


def sc(request, file_id):
    sc_obj = ShouCang.objects.filter(user=request.session.get('username'), file_data_id=file_id).first()
    if sc_obj:
        return JsonResponse({"result": 201}, status=502)
    ShouCang.objects.create(
        user=request.session.get('username'),
        file_data_id=file_id
    )
    return JsonResponse({"result": 201})


def download(request, file_id):
    report = FileTable.objects.filter(id=file_id).first()
    pid = report.pid
    parent_name = FileTable.objects.filter(id=pid).first().name
    name = report.name
    file_path = os.path.join(settings.BASE_DIR, 'static', 'file_data', parent_name,
                             report.name)
    print(file_path)
    try:
        # 设置响应头
        # StreamingHttpResponse将文件内容进行流式传输，数据量大可以用这个方法
        response = StreamingHttpResponse(file_iterator(file_path))
        # 以流的形式下载文件,这样可以实现任意格式的文件下载
        response['Content-Type'] = 'application/octet-stream'
        # Content-Disposition就是当用户想把请求所得的内容存为一个文件的时候提供一个默认的文件名
        response['Content-Disposition'] = 'attachment;filename="{}"'.format(escape_uri_path(report.name))
    except Exception as e:
        return HttpResponse("Sorry but Not Found the File")
    return response


def download_file(request, file_id):
    report = Info.objects.filter(id=file_id).first()
    name = report.name
    file_path = os.path.join(settings.BASE_DIR, 'static', 'docx', name + '.pdf')
    try:
        # 设置响应头
        # StreamingHttpResponse将文件内容进行流式传输，数据量大可以用这个方法
        response = StreamingHttpResponse(file_iterator(file_path))
        # 以流的形式下载文件,这样可以实现任意格式的文件下载
        response['Content-Type'] = 'application/octet-stream'
        # Content-Disposition就是当用户想把请求所得的内容存为一个文件的时候提供一个默认的文件名
        response['Content-Disposition'] = 'attachment;filename="{}"'.format(escape_uri_path(name + '.pdf'))
    except Exception as e:
        return HttpResponse("文件不存在，可能在检测报告模块已删除！！！")
    return response


def download_file1(request, file_id):
    report = Paper.objects.filter(id=file_id).first()
    name = report.path
    file_path = os.path.join(settings.BASE_DIR, 'static', 'docx', name)
    try:
        # 设置响应头
        # StreamingHttpResponse将文件内容进行流式传输，数据量大可以用这个方法
        response = StreamingHttpResponse(file_iterator(file_path))
        # 以流的形式下载文件,这样可以实现任意格式的文件下载
        response['Content-Type'] = 'application/octet-stream'
        # Content-Disposition就是当用户想把请求所得的内容存为一个文件的时候提供一个默认的文件名
        response['Content-Disposition'] = 'attachment;filename="{}"'.format(escape_uri_path(name))
    except Exception as e:
        return HttpResponse("Sorry but Not Found the File")
    return response
