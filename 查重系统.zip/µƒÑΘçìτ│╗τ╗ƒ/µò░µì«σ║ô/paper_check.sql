/*
 Navicat Premium Data Transfer

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 80032
 Source Host           : localhost:3306
 Source Schema         : paper_check

 Target Server Type    : MySQL
 Target Server Version : 80032
 File Encoding         : 65001

 Date: 16/04/2023 08:28:17
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for auth_group
-- ----------------------------
DROP TABLE IF EXISTS `auth_group`;
CREATE TABLE `auth_group`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `name`(`name` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of auth_group
-- ----------------------------

-- ----------------------------
-- Table structure for auth_group_permissions
-- ----------------------------
DROP TABLE IF EXISTS `auth_group_permissions`;
CREATE TABLE `auth_group_permissions`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `group_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `auth_group_permissions_group_id_permission_id_0cd325b0_uniq`(`group_id` ASC, `permission_id` ASC) USING BTREE,
  INDEX `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm`(`permission_id` ASC) USING BTREE,
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of auth_group_permissions
-- ----------------------------

-- ----------------------------
-- Table structure for auth_permission
-- ----------------------------
DROP TABLE IF EXISTS `auth_permission`;
CREATE TABLE `auth_permission`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `content_type_id` int NOT NULL,
  `codename` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `auth_permission_content_type_id_codename_01ab375a_uniq`(`content_type_id` ASC, `codename` ASC) USING BTREE,
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 57 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of auth_permission
-- ----------------------------
INSERT INTO `auth_permission` VALUES (1, 'Can add log entry', 1, 'add_logentry');
INSERT INTO `auth_permission` VALUES (2, 'Can change log entry', 1, 'change_logentry');
INSERT INTO `auth_permission` VALUES (3, 'Can delete log entry', 1, 'delete_logentry');
INSERT INTO `auth_permission` VALUES (4, 'Can view log entry', 1, 'view_logentry');
INSERT INTO `auth_permission` VALUES (5, 'Can add permission', 2, 'add_permission');
INSERT INTO `auth_permission` VALUES (6, 'Can change permission', 2, 'change_permission');
INSERT INTO `auth_permission` VALUES (7, 'Can delete permission', 2, 'delete_permission');
INSERT INTO `auth_permission` VALUES (8, 'Can view permission', 2, 'view_permission');
INSERT INTO `auth_permission` VALUES (9, 'Can add group', 3, 'add_group');
INSERT INTO `auth_permission` VALUES (10, 'Can change group', 3, 'change_group');
INSERT INTO `auth_permission` VALUES (11, 'Can delete group', 3, 'delete_group');
INSERT INTO `auth_permission` VALUES (12, 'Can view group', 3, 'view_group');
INSERT INTO `auth_permission` VALUES (13, 'Can add user', 4, 'add_user');
INSERT INTO `auth_permission` VALUES (14, 'Can change user', 4, 'change_user');
INSERT INTO `auth_permission` VALUES (15, 'Can delete user', 4, 'delete_user');
INSERT INTO `auth_permission` VALUES (16, 'Can view user', 4, 'view_user');
INSERT INTO `auth_permission` VALUES (17, 'Can add content type', 5, 'add_contenttype');
INSERT INTO `auth_permission` VALUES (18, 'Can change content type', 5, 'change_contenttype');
INSERT INTO `auth_permission` VALUES (19, 'Can delete content type', 5, 'delete_contenttype');
INSERT INTO `auth_permission` VALUES (20, 'Can view content type', 5, 'view_contenttype');
INSERT INTO `auth_permission` VALUES (21, 'Can add session', 6, 'add_session');
INSERT INTO `auth_permission` VALUES (22, 'Can change session', 6, 'change_session');
INSERT INTO `auth_permission` VALUES (23, 'Can delete session', 6, 'delete_session');
INSERT INTO `auth_permission` VALUES (24, 'Can view session', 6, 'view_session');
INSERT INTO `auth_permission` VALUES (25, 'Can add pic', 7, 'add_pic');
INSERT INTO `auth_permission` VALUES (26, 'Can change pic', 7, 'change_pic');
INSERT INTO `auth_permission` VALUES (27, 'Can delete pic', 7, 'delete_pic');
INSERT INTO `auth_permission` VALUES (28, 'Can view pic', 7, 'view_pic');
INSERT INTO `auth_permission` VALUES (29, 'Can add role', 8, 'add_role');
INSERT INTO `auth_permission` VALUES (30, 'Can change role', 8, 'change_role');
INSERT INTO `auth_permission` VALUES (31, 'Can delete role', 8, 'delete_role');
INSERT INTO `auth_permission` VALUES (32, 'Can view role', 8, 'view_role');
INSERT INTO `auth_permission` VALUES (33, 'Can add user', 9, 'add_user');
INSERT INTO `auth_permission` VALUES (34, 'Can change user', 9, 'change_user');
INSERT INTO `auth_permission` VALUES (35, 'Can delete user', 9, 'delete_user');
INSERT INTO `auth_permission` VALUES (36, 'Can view user', 9, 'view_user');
INSERT INTO `auth_permission` VALUES (37, 'Can add info', 10, 'add_info');
INSERT INTO `auth_permission` VALUES (38, 'Can change info', 10, 'change_info');
INSERT INTO `auth_permission` VALUES (39, 'Can delete info', 10, 'delete_info');
INSERT INTO `auth_permission` VALUES (40, 'Can view info', 10, 'view_info');
INSERT INTO `auth_permission` VALUES (41, 'Can add file table', 11, 'add_filetable');
INSERT INTO `auth_permission` VALUES (42, 'Can change file table', 11, 'change_filetable');
INSERT INTO `auth_permission` VALUES (43, 'Can delete file table', 11, 'delete_filetable');
INSERT INTO `auth_permission` VALUES (44, 'Can view file table', 11, 'view_filetable');
INSERT INTO `auth_permission` VALUES (45, 'Can add shou cang', 12, 'add_shoucang');
INSERT INTO `auth_permission` VALUES (46, 'Can change shou cang', 12, 'change_shoucang');
INSERT INTO `auth_permission` VALUES (47, 'Can delete shou cang', 12, 'delete_shoucang');
INSERT INTO `auth_permission` VALUES (48, 'Can view shou cang', 12, 'view_shoucang');
INSERT INTO `auth_permission` VALUES (49, 'Can add paper', 13, 'add_paper');
INSERT INTO `auth_permission` VALUES (50, 'Can change paper', 13, 'change_paper');
INSERT INTO `auth_permission` VALUES (51, 'Can delete paper', 13, 'delete_paper');
INSERT INTO `auth_permission` VALUES (52, 'Can view paper', 13, 'view_paper');
INSERT INTO `auth_permission` VALUES (53, 'Can add crawer', 14, 'add_crawer');
INSERT INTO `auth_permission` VALUES (54, 'Can change crawer', 14, 'change_crawer');
INSERT INTO `auth_permission` VALUES (55, 'Can delete crawer', 14, 'delete_crawer');
INSERT INTO `auth_permission` VALUES (56, 'Can view crawer', 14, 'view_crawer');

-- ----------------------------
-- Table structure for auth_user
-- ----------------------------
DROP TABLE IF EXISTS `auth_user`;
CREATE TABLE `auth_user`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `password` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `last_login` datetime(6) NULL DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `first_name` varchar(150) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `last_name` varchar(150) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `email` varchar(254) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `username`(`username` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of auth_user
-- ----------------------------

-- ----------------------------
-- Table structure for auth_user_groups
-- ----------------------------
DROP TABLE IF EXISTS `auth_user_groups`;
CREATE TABLE `auth_user_groups`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `group_id` int NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `auth_user_groups_user_id_group_id_94350c0c_uniq`(`user_id` ASC, `group_id` ASC) USING BTREE,
  INDEX `auth_user_groups_group_id_97559544_fk_auth_group_id`(`group_id` ASC) USING BTREE,
  CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of auth_user_groups
-- ----------------------------

-- ----------------------------
-- Table structure for auth_user_user_permissions
-- ----------------------------
DROP TABLE IF EXISTS `auth_user_user_permissions`;
CREATE TABLE `auth_user_user_permissions`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq`(`user_id` ASC, `permission_id` ASC) USING BTREE,
  INDEX `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm`(`permission_id` ASC) USING BTREE,
  CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of auth_user_user_permissions
-- ----------------------------

-- ----------------------------
-- Table structure for crawer
-- ----------------------------
DROP TABLE IF EXISTS `crawer`;
CREATE TABLE `crawer`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `content` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `score` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `result` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `create_time` datetime(6) NOT NULL,
  `owner` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `number` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `total_zs` int NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of crawer
-- ----------------------------
INSERT INTO `crawer` VALUES (1, '多地商家立网红路牌涉违规被拆 官方：不能为引流随意设置', '0.00%', '秦刚：中德是伙伴不是对手，要合作不要对抗', '2023-04-15 16:19:21.869281', '', 'lh4zIM', 27);
INSERT INTO `crawer` VALUES (3, '2022中国金球奖颁奖：张玉宁首捧金球 水庆霞当选金帅', '100.00%', '2022中国金球奖颁奖：张玉宁首捧金球 水庆霞当选金帅', '2023-04-15 16:25:25.481040', '', 'ywPx74', 27);
INSERT INTO `crawer` VALUES (4, '2022中国金球奖颁奖', '85.00%', '2022中国金球奖颁奖：张玉宁首捧金球 水庆霞当选金帅', '2023-04-15 16:33:50.966454', '', 'U2EwUr', 11);
INSERT INTO `crawer` VALUES (5, '2022中国金球奖颁奖', '85.00%', '2022中国金球奖颁奖：张玉宁首捧金球 水庆霞当选金帅', '2023-04-15 16:38:31.932132', '', 'o3v6aB', 11);
INSERT INTO `crawer` VALUES (6, '张玉宁首捧金球 水庆霞当选金帅', '65.00%', '2022中国金球奖颁奖：张玉宁首捧金球 水庆霞当选金帅', '2023-04-15 16:55:53.735075', '', 'ymX1oC', 15);

-- ----------------------------
-- Table structure for django_admin_log
-- ----------------------------
DROP TABLE IF EXISTS `django_admin_log`;
CREATE TABLE `django_admin_log`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NULL DEFAULT NULL,
  `object_id` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL,
  `object_repr` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `action_flag` smallint UNSIGNED NOT NULL,
  `change_message` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `content_type_id` int NULL DEFAULT NULL,
  `user_id` int NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `django_admin_log_content_type_id_c4bce8eb_fk_django_co`(`content_type_id` ASC) USING BTREE,
  INDEX `django_admin_log_user_id_c564eba6_fk_auth_user_id`(`user_id` ASC) USING BTREE,
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of django_admin_log
-- ----------------------------

-- ----------------------------
-- Table structure for django_content_type
-- ----------------------------
DROP TABLE IF EXISTS `django_content_type`;
CREATE TABLE `django_content_type`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `model` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `django_content_type_app_label_model_76bd3d3b_uniq`(`app_label` ASC, `model` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 15 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of django_content_type
-- ----------------------------
INSERT INTO `django_content_type` VALUES (1, 'admin', 'logentry');
INSERT INTO `django_content_type` VALUES (3, 'auth', 'group');
INSERT INTO `django_content_type` VALUES (2, 'auth', 'permission');
INSERT INTO `django_content_type` VALUES (4, 'auth', 'user');
INSERT INTO `django_content_type` VALUES (5, 'contenttypes', 'contenttype');
INSERT INTO `django_content_type` VALUES (14, 'index', 'crawer');
INSERT INTO `django_content_type` VALUES (11, 'index', 'filetable');
INSERT INTO `django_content_type` VALUES (10, 'index', 'info');
INSERT INTO `django_content_type` VALUES (13, 'index', 'paper');
INSERT INTO `django_content_type` VALUES (7, 'index', 'pic');
INSERT INTO `django_content_type` VALUES (12, 'index', 'shoucang');
INSERT INTO `django_content_type` VALUES (6, 'sessions', 'session');
INSERT INTO `django_content_type` VALUES (8, 'user', 'role');
INSERT INTO `django_content_type` VALUES (9, 'user', 'user');

-- ----------------------------
-- Table structure for django_migrations
-- ----------------------------
DROP TABLE IF EXISTS `django_migrations`;
CREATE TABLE `django_migrations`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `app` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `applied` datetime(6) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 31 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of django_migrations
-- ----------------------------
INSERT INTO `django_migrations` VALUES (1, 'contenttypes', '0001_initial', '2023-04-11 22:12:40.931943');
INSERT INTO `django_migrations` VALUES (2, 'auth', '0001_initial', '2023-04-11 22:12:42.580974');
INSERT INTO `django_migrations` VALUES (3, 'admin', '0001_initial', '2023-04-11 22:12:45.412510');
INSERT INTO `django_migrations` VALUES (4, 'admin', '0002_logentry_remove_auto_add', '2023-04-11 22:12:45.459499');
INSERT INTO `django_migrations` VALUES (5, 'admin', '0003_logentry_add_action_flag_choices', '2023-04-11 22:12:45.492592');
INSERT INTO `django_migrations` VALUES (6, 'contenttypes', '0002_remove_content_type_name', '2023-04-11 22:12:46.299140');
INSERT INTO `django_migrations` VALUES (7, 'auth', '0002_alter_permission_name_max_length', '2023-04-11 22:12:46.906068');
INSERT INTO `django_migrations` VALUES (8, 'auth', '0003_alter_user_email_max_length', '2023-04-11 22:12:47.501274');
INSERT INTO `django_migrations` VALUES (9, 'auth', '0004_alter_user_username_opts', '2023-04-11 22:12:47.541466');
INSERT INTO `django_migrations` VALUES (10, 'auth', '0005_alter_user_last_login_null', '2023-04-11 22:12:47.980272');
INSERT INTO `django_migrations` VALUES (11, 'auth', '0006_require_contenttypes_0002', '2023-04-11 22:12:48.014569');
INSERT INTO `django_migrations` VALUES (12, 'auth', '0007_alter_validators_add_error_messages', '2023-04-11 22:12:48.062559');
INSERT INTO `django_migrations` VALUES (13, 'auth', '0008_alter_user_username_max_length', '2023-04-11 22:12:48.647021');
INSERT INTO `django_migrations` VALUES (14, 'auth', '0009_alter_user_last_name_max_length', '2023-04-11 22:12:49.234074');
INSERT INTO `django_migrations` VALUES (15, 'auth', '0010_alter_group_name_max_length', '2023-04-11 22:12:49.707332');
INSERT INTO `django_migrations` VALUES (16, 'auth', '0011_update_proxy_permissions', '2023-04-11 22:12:49.748356');
INSERT INTO `django_migrations` VALUES (17, 'auth', '0012_alter_user_first_name_max_length', '2023-04-11 22:12:50.290907');
INSERT INTO `django_migrations` VALUES (18, 'sessions', '0001_initial', '2023-04-11 22:12:50.749018');
INSERT INTO `django_migrations` VALUES (19, 'index', '0001_initial', '2023-04-11 22:16:17.964419');
INSERT INTO `django_migrations` VALUES (20, 'user', '0001_initial', '2023-04-11 22:16:18.193516');
INSERT INTO `django_migrations` VALUES (21, 'index', '0002_auto_20230412_1429', '2023-04-13 21:57:15.735369');
INSERT INTO `django_migrations` VALUES (22, 'index', '0003_filetable', '2023-04-13 21:57:15.830716');
INSERT INTO `django_migrations` VALUES (23, 'index', '0004_shoucang', '2023-04-14 13:11:29.502902');
INSERT INTO `django_migrations` VALUES (24, 'index', '0005_auto_20230414_1439', '2023-04-14 14:39:07.695040');
INSERT INTO `django_migrations` VALUES (25, 'index', '0006_paper', '2023-04-15 09:55:18.694299');
INSERT INTO `django_migrations` VALUES (26, 'index', '0007_auto_20230415_0957', '2023-04-15 09:57:40.414153');
INSERT INTO `django_migrations` VALUES (27, 'index', '0008_crawer', '2023-04-15 11:24:53.362327');
INSERT INTO `django_migrations` VALUES (28, 'index', '0009_auto_20230415_1608', '2023-04-15 16:08:20.818209');
INSERT INTO `django_migrations` VALUES (29, 'index', '0010_crawer_number', '2023-04-15 16:08:59.157340');
INSERT INTO `django_migrations` VALUES (30, 'index', '0011_crawer_total_zs', '2023-04-15 16:16:19.021017');

-- ----------------------------
-- Table structure for django_session
-- ----------------------------
DROP TABLE IF EXISTS `django_session`;
CREATE TABLE `django_session`  (
  `session_key` varchar(40) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `session_data` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `expire_date` datetime(6) NULL DEFAULT NULL,
  PRIMARY KEY (`session_key`) USING BTREE,
  INDEX `django_session_expire_date_a5c62663`(`expire_date` ASC) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of django_session
-- ----------------------------
INSERT INTO `django_session` VALUES ('grc2y0c1s1oxb2mcjvinmb5l4bqi9a34', 'eyJ1c2VybmFtZSI6ImFkbWluIiwicm9sZSI6MiwidXNlcl9pZCI6Mn0:1pmxWD:YIUdWDWk_z96-ZabG6kdFcP7AQn8mZxCne_O1YZ0IPg', '2023-04-27 22:01:45.122491');
INSERT INTO `django_session` VALUES ('n27777v2mkjpppgts4hdacait35a2whx', 'eyJyb2xlIjoxLCJ1c2VyX2lkIjoyLCJ1c2VybmFtZSI6ImFkbWluIn0:1pnVUg:0Fr4f9K5A78m_5rLMfuzxdzIZBjFHBEYLx2oN2cmPhg', '2023-04-29 10:18:26.564641');
INSERT INTO `django_session` VALUES ('s5iwalrjv3yqc942vkq2vceh3yrfzjwz', 'eyJyb2xlIjoxLCJ1c2VyX2lkIjoyLCJ1c2VybmFtZSI6ImFkbWluIn0:1pnhCu:mxTlwkRQEr-FX8jq0DPwTSS3DpCF2zMHmqYk2J9V1AI', '2023-04-29 22:48:52.473513');
INSERT INTO `django_session` VALUES ('y3fuxcn7vswt0fxz5odeinoijyptrq8r', 'eyJ1c2VybmFtZSI6ImFkbWluIiwicm9sZSI6MiwidXNlcl9pZCI6Mn0:1pnB7F:ai2lwXmJYVHj6uAwGOfkjJ3wUlObJN7urOiOt6Cgays', '2023-04-28 12:32:53.076818');

-- ----------------------------
-- Table structure for file_table
-- ----------------------------
DROP TABLE IF EXISTS `file_table`;
CREATE TABLE `file_table`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `size` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `file_type` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `lw_name` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `author` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `owner` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `pid` int NOT NULL,
  `create_time` datetime(6) NULL DEFAULT NULL,
  `content` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 13 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of file_table
-- ----------------------------
INSERT INTO `file_table` VALUES (4, 'test.txt', '802kb', 'txt', '开题', '张三', 'admin', 1, '2023-04-13 23:31:02.669305', '“我在重庆很想你”“想你的风还是吹到了重庆”，蓝底白字的深情标语，就是这样的一块路牌，或立于嘉陵江路旁，望见车水马龙；或伫于长江水畔，一眼望去，江水风光尽收眼底。“我在××很想你”，这阵“风”愈吹愈热，愈吹愈远，“浪漫风”系列路牌出现在各个城市。曾几何时，与“竖立”于马路旁的“一阵风”拍个照，发个朋友圈或抖音，引得人纷纷效仿，甚至询问这阵“风”在哪里，大排长龙。而如今，这阵“风”却被指出土得掉渣，俗不可耐。这些路牌，既存在得莫名其妙，又无文化底蕴，除了成为一次性的网红打卡点外，怕也留不住消费者的脚步，只会变成一吹即散的“网红风”。');
INSERT INTO `file_table` VALUES (5, '111', '0', '文本', '111', '111', 'admin', 0, '2023-04-13 23:41:27.098708', '近日，习近平总书记在广东考察，这是2023年全国两会后总书记首次地方考察。4月10日，总书记在有“红树林之城”美誉的湛江考察了麻章区湖光镇金牛岛红树林片区。\n\n这一红树林片区位于我国红树林面积最大、分布最集中的自然保护区——广东湛江红树林国家级自然保护区东部。红树林素有“海岸卫士、鸟类天堂、鱼虾粮仓”的美誉，是最重要的蓝碳生态系统之一，在净化海水、防风消浪、维持生物多样性、固碳储碳等方面发挥着极为重要的作用。');
INSERT INTO `file_table` VALUES (7, '测试文件夹1', '0', '文件夹', '', '', 'admin', 0, '2023-04-15 09:50:00.062868', '');
INSERT INTO `file_table` VALUES (8, 'test.py', '313字节', 'py', '基于人工智能的自动识别系统', '王毛毛', 'admin', 7, '2023-04-15 09:51:58.882619', 'import os\n\nfrom PIL import Image\n\npath = r\'D:\\mycode\\202303\\horse\\cnn_classify\\newdata\\train\'\ncount = 1\nfor root,dirs,files in os.walk(path):\n    for filename in files:\n        filepath = os.path.join(root, filename)\n        os.rename(filepath,os.path.join(root, str(count)+\'.jpg\'))\n        count+=1\n\n');
INSERT INTO `file_table` VALUES (9, '测试文件3', '0', '文件夹', '', '', 'admin', 0, '2023-04-15 16:50:17.263145', '');
INSERT INTO `file_table` VALUES (10, 'test.txt', '802字节', 'txt', '基于机器学习的情感分析', '毛利兰', 'admin', 7, '2023-04-15 16:50:47.464166', '“我在重庆很想你”“想你的风还是吹到了重庆”，蓝底白字的深情标语，就是这样的一块路牌，或立于嘉陵江路旁，望见车水马龙；或伫于长江水畔，一眼望去，江水风光尽收眼底。“我在××很想你”，这阵“风”愈吹愈热，愈吹愈远，“浪漫风”系列路牌出现在各个城市。曾几何时，与“竖立”于马路旁的“一阵风”拍个照，发个朋友圈或抖音，引得人纷纷效仿，甚至询问这阵“风”在哪里，大排长龙。而如今，这阵“风”却被指出土得掉渣，俗不可耐。这些路牌，既存在得莫名其妙，又无文化底蕴，除了成为一次性的网红打卡点外，怕也留不住消费者的脚步，只会变成一吹即散的“网红风”。');
INSERT INTO `file_table` VALUES (11, 'test.txt', '802字节', 'txt', '11', '11', 'admin', 9, '2023-04-15 16:51:43.762346', '“我在重庆很想你”“想你的风还是吹到了重庆”，蓝底白字的深情标语，就是这样的一块路牌，或立于嘉陵江路旁，望见车水马龙；或伫于长江水畔，一眼望去，江水风光尽收眼底。“我在××很想你”，这阵“风”愈吹愈热，愈吹愈远，“浪漫风”系列路牌出现在各个城市。曾几何时，与“竖立”于马路旁的“一阵风”拍个照，发个朋友圈或抖音，引得人纷纷效仿，甚至询问这阵“风”在哪里，大排长龙。而如今，这阵“风”却被指出土得掉渣，俗不可耐。这些路牌，既存在得莫名其妙，又无文化底蕴，除了成为一次性的网红打卡点外，怕也留不住消费者的脚步，只会变成一吹即散的“网红风”。');
INSERT INTO `file_table` VALUES (12, 'test.txt', '802字节', 'txt', '123', '12', 'admin', 7, '2023-04-15 16:52:20.776657', '“我在重庆很想你”“想你的风还是吹到了重庆”，蓝底白字的深情标语，就是这样的一块路牌，或立于嘉陵江路旁，望见车水马龙；或伫于长江水畔，一眼望去，江水风光尽收眼底。“我在××很想你”，这阵“风”愈吹愈热，愈吹愈远，“浪漫风”系列路牌出现在各个城市。曾几何时，与“竖立”于马路旁的“一阵风”拍个照，发个朋友圈或抖音，引得人纷纷效仿，甚至询问这阵“风”在哪里，大排长龙。而如今，这阵“风”却被指出土得掉渣，俗不可耐。这些路牌，既存在得莫名其妙，又无文化底蕴，除了成为一次性的网红打卡点外，怕也留不住消费者的脚步，只会变成一吹即散的“网红风”。');

-- ----------------------------
-- Table structure for info
-- ----------------------------
DROP TABLE IF EXISTS `info`;
CREATE TABLE `info`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `result` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `status` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `create_time` datetime(6) NULL DEFAULT NULL,
  `author` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `content` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL,
  `note` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `number` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `total_zs` int NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 8 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of info
-- ----------------------------
INSERT INTO `info` VALUES (2, '测试1', '1.0', '成功', '2023-04-14 17:11:37.850220', '测试', '', '[{\'name\': \'111\', \'result\': \'1.0\'}]', 'hgvc1A', 206);
INSERT INTO `info` VALUES (3, '大数据分析', '31.00%', '成功', '2023-04-14 17:30:35.905749', '123', '发挥着极为重要的作用', '[{\'name\': \'test.txt\', \'result\': 0.0}, {\'name\': \'111\', \'result\': 0.31}]', 'pA1t21', 10);
INSERT INTO `info` VALUES (4, '测111', '31.00%', '成功', '2023-04-14 17:57:32.672550', '1111', '发挥着极为重要的作用', '[{\'name\': \'test.txt\', \'result\': 0.0}, {\'name\': \'111\', \'result\': 0.31}]', 't5DYVo', 10);
INSERT INTO `info` VALUES (5, '基于python的文本检测系统', '5.00%', '成功', '2023-04-14 18:05:19.638488', '李五子', '千年大运河承载着自强不息的精神和人与自然和谐相处的智慧。随着遗址发掘保护工作不断取得新进展，大运河的精神内涵将得到更加充分的展现。', '[{\'name\': \'test.txt\', \'result\': \'0.00%\'}, {\'name\': \'111\', \'result\': \'5.00%\'}]', 'mdO9go', 65);
INSERT INTO `info` VALUES (6, '基于java+vue的校园管理系统', '0.00%', '成功', '2023-04-15 10:16:33.213688', '吴凯', '“我在重庆很想你”“想你的风还是吹到了重庆”，蓝底白字的深情标语，就是这样的一块路牌，或立于嘉陵江路旁，望见车水马龙；或伫于长江水畔，一眼望去，江水风光尽收眼底。“我在××很想你”，这阵“风”愈吹愈热，愈吹愈远，“浪漫风”系列路牌出现在各个城市。曾几何时，与“竖立”于马路旁的“一阵风”拍个照，发个朋友圈或抖音，引得人纷纷效仿，甚至询问这阵“风”在哪里，大排长龙。而如今，这阵“风”却被指出土得掉渣，俗不可耐。这些路牌，既存在得莫名其妙，又无文化底蕴，除了成为一次性的网红打卡点外，怕也留不住消费者的脚步，只会变成一吹即散的“网红风”。', '[{\'name\': \'111\', \'result\': \'0.00%\'}, {\'name\': \'test.py\', \'result\': \'0.00%\'}]', '7gcIyy', 268);
INSERT INTO `info` VALUES (7, '基于java的校园系统', '0.00%', '成功', '2023-04-15 16:55:07.579787', '王万寿', '测试你好啊哈哈哈哈哈哈达撒大声地', '[{\'name\': \'test.txt\', \'result\': \'0.00%\'}, {\'name\': \'111\', \'result\': \'0.00%\'}, {\'name\': \'test.py\', \'result\': \'0.00%\'}, {\'name\': \'test.txt\', \'result\': \'0.00%\'}, {\'name\': \'test.txt\', \'result\': \'0.00%\'}, {\'name\': \'test.txt\', \'result\': \'0.00%\'}]', '4k2pw8', 16);

-- ----------------------------
-- Table structure for paper
-- ----------------------------
DROP TABLE IF EXISTS `paper`;
CREATE TABLE `paper`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `path` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `info_id` int NOT NULL,
  `create_time` datetime(6) NOT NULL,
  `owner` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `paper_info_id_27897bbc_fk_info_id`(`info_id` ASC) USING BTREE,
  CONSTRAINT `paper_info_id_27897bbc_fk_info_id` FOREIGN KEY (`info_id`) REFERENCES `info` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of paper
-- ----------------------------
INSERT INTO `paper` VALUES (1, '基于java+vue的校园管理系统.pdf', 6, '2023-04-15 10:16:33.219716', 'admin');
INSERT INTO `paper` VALUES (2, '基于java的校园系统.pdf', 7, '2023-04-15 16:55:07.583778', 'admin');

-- ----------------------------
-- Table structure for role
-- ----------------------------
DROP TABLE IF EXISTS `role`;
CREATE TABLE `role`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `abbreviation` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `remark` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `order` int NULL DEFAULT NULL,
  `create_time` datetime(6) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of role
-- ----------------------------
INSERT INTO `role` VALUES (1, '管理员', 'admin', 'admin', 1, '2023-04-11 22:17:15.000000');
INSERT INTO `role` VALUES (2, '普通用户', 'user', 'user', 2, '2023-04-11 22:17:26.000000');

-- ----------------------------
-- Table structure for shoucang
-- ----------------------------
DROP TABLE IF EXISTS `shoucang`;
CREATE TABLE `shoucang`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `user` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `file_data_id` int NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `shoucang_file_data_id_82416eb8_fk_file_table_id`(`file_data_id` ASC) USING BTREE,
  CONSTRAINT `shoucang_file_data_id_82416eb8_fk_file_table_id` FOREIGN KEY (`file_data_id`) REFERENCES `file_table` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of shoucang
-- ----------------------------
INSERT INTO `shoucang` VALUES (2, 'admin', 4);
INSERT INTO `shoucang` VALUES (3, 'admin', 8);
INSERT INTO `shoucang` VALUES (4, 'admin', 11);

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `password` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `email` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `phone` varchar(11) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `create_time` datetime(6) NULL DEFAULT NULL,
  `modify_time` datetime(6) NULL DEFAULT NULL,
  `description` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `role_id` int NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `user_role_id_c3a87a3d_fk_role_id`(`role_id` ASC) USING BTREE,
  CONSTRAINT `user_role_id_c3a87a3d_fk_role_id` FOREIGN KEY (`role_id`) REFERENCES `role` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES (2, 'admin', '123', '1@qq.com', '12345678992', '2023-04-11 22:17:32.009607', '2023-04-11 22:17:32.009607', '', 1);
INSERT INTO `user` VALUES (3, '王五', '1234', '1@qq.com', '11111111111', '2023-04-15 16:49:42.640491', '2023-04-15 16:49:42.640491', '', 2);
INSERT INTO `user` VALUES (4, '网三', '123', '1@qq.com', '12345678963', '2023-04-15 16:58:19.801704', '2023-04-15 16:58:19.801704', '', 2);

SET FOREIGN_KEY_CHECKS = 1;
